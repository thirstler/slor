from slor.shared import *
from slor.process import SlorProcess

class Workload(SlorProcess):

    def __init__(self, socket, config, w_id, id):
        pass

    